import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Nivel3 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Nivel3 extends World
{
    public static int score = 0;
    /**
     * Constructor for objects of class Nivel3.
     * 
     */
    public Nivel3()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        prepare();
    }
    
    public void act()
    {
        spawnal();
        showText("Score: " + score, 50, 25);

    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        score = 0;
        Persona persona = new Persona();
        addObject(persona,45,362);
        persona.setLocation(45,362);
    } 
    
    public void spawnal()
    {
        if (Greenfoot.getRandomNumber(50)==15)
        {
            int x = Greenfoot.getRandomNumber(getWidth());
            int y = 0;
            addObject(new Mascarilla(), x, y);
        } 
        
        if (Greenfoot.getRandomNumber(100)==15)
        {
            int x = Greenfoot.getRandomNumber(getWidth());
            int y = 0;
            addObject(new Covid(), x, y);
        } 
        
        if (Greenfoot.getRandomNumber(100)==15)
        {
            int x = Greenfoot.getRandomNumber(getWidth());
            int y = 0;
            addObject(new Vacuna(), x, y);
         }   
        
        if (Greenfoot.getRandomNumber(100)==15)
        {
            int x = Greenfoot.getRandomNumber(getWidth());
            int y = 0;
            addObject(new Gel(), x, y);
         } 

         
        if (score == 35)
        Greenfoot.setWorld(new End());
        }
    }

