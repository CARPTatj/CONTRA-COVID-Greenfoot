import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Persona here.
 * 
 * @author (Alina Tatjana Carias Portillo) 
 * @version (a version number or a date)
 */
public class Persona extends Actor
{
    /**
     * Act - do whatever the Persona wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    MyWorld thisGame;
    Nivel2 secGame;
    Nivel3 trhdGame;
    public void act()
    {
        // Add your action code here.
        move();
        eat();
        hitCovid();
    }
    
    public void move()
    {
        if (Greenfoot.isKeyDown("Left"))
        {
            move(-5);
        }
        if (Greenfoot.isKeyDown("Right"))
        {
            move(5);
        }
    }
    
    public void eat()
    {
        if (isTouching(Mascarilla.class))
        {
            removeTouching(Mascarilla.class);
            thisGame.score++;
            secGame.score++;
            trhdGame.score++;
        }
        
        if (isTouching(Vacuna.class))
        {
            removeTouching(Vacuna.class);
            thisGame.score++;
            secGame.score++;
            trhdGame.score++;
        }
        
        if (isTouching(Gel.class))
        {
            removeTouching(Gel.class);
            thisGame.score++;
            secGame.score++;
            trhdGame.score++;
        }
    }
    
    public void hitCovid()
    {
        if (isTouching(Covid.class))
        {
            getWorld().removeObject(this);
            Greenfoot.playSound("masca.wav");
            Greenfoot.stop();
        }
    }
}
