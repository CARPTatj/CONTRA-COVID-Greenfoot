import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Gel here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Gel extends Actor
{
    /**
     * Act - do whatever the Gel wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
       {
        // Add your action code here.
        
        image();
        move();
        removeFromWorld();
    }
    
    public void image()
    {
      GreenfootImage image = getImage();  
        image.scale(40, 40);
        setImage(image);  
    }
    
    public void move()
    {
        setRotation(90);
        move(4);
    }
    
    public void removeFromWorld()
    {
        if (getY() == 399)
        {
            getWorld().removeObject(this);
        }
    }
}
